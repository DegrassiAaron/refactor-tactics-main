# RefactorTactics Tactical Geometry Boards v0.1

Grammatica invariata:
- Colore = fase/timing
- Geometria = Shape/Area
- Icona = effetto/proprietà
- Numero = quantità
- Posizione = categoria
- Glifi secondari = modificatori

A1 Radial Hex: orbitale
A2 Tactical Syntax Strip: frase visiva
A3 Concentric Layer: livelli concentrici
A4 Compact HUD Tiles: stress-test HUD
