# Applicazione a `refactor-tactics-main`

Copiare/aggiornare la cartella `docs/`.

La v0.7 aggiunge:

- `docs/characters/paragon.md` — indice dei 38 hero asset Paragon;
- `docs/characters/candidates/` — 34 nuove pagine;
- `docs/characters/images/paragon/` — 38 Wiki card locali;
- immagini collegate anche alle quattro pagine v0.2;
- manifest `paragon-wiki-manifest-v0.7.json`.

## Regola di autorità

Le pagine Wiki sono **derivate e non normative**. I 34 candidati restano `SIGNATURE_DEFINED / UNASSIGNED`; non promuoverli in roadmap o runtime solo perché hanno una pagina Wiki.

## Immagini

Le card locali sono placeholder informativi. Per immagini definitive, sostituire i PNG con screenshot in-engine degli asset Paragon mantenendo gli stessi filename.

Commit suggerito:

`docs: add wiki pages for all Paragon hero asset slots`
