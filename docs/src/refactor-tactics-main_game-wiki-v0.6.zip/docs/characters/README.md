# RefactorTactics — Character Wiki

> **Dataset:** v0.4 · **Roster pianificato:** 8 personaggi · **Aggiornato:** 2026-08-08

Questa cartella contiene la Wiki operativa dei personaggi di RefactorTactics. Le pagine combinano **dati strutturati**
e **descrizioni gameplay** per rendere leggibili identità, meccanica firma, skill, reaction, risorse, varianti e stato
di implementazione.

## Roster per release

### v0.1 — roster canonico corrente

- [Flux](v0.1/flux.md) — Conduction / Carica Conduttiva
- [Riva](v0.1/riva.md) — Water Shaping / Riserva Idrica
- [Bastion](v0.1/bastion.md) — Field Architecture / Integrità Strutturale
- [Vektor](v0.1/vektor.md) — Predictive Interception / Slancio

### v0.2 — roster pianificato

- [Steel](v0.2/steel.md) — Guard Meter / Integrità Scudo
- [Aurora](v0.2/aurora.md) — Frozen Domain / Cariche Termiche
- [Murdock](v0.2/murdock.md) — Focus + Fire Sector / Munizioni Speciali
- [Kwang](v0.2/kwang.md) — Electric Anchor / Carica Tempesta

## Cosa deve contenere ogni pagina

Ogni pagina ufficiale deve includere:

1. panoramica e identità tattica;
2. **descrizione della meccanica firma**, con payoff e counterplay;
3. statistiche, visione, mobilità e risorsa firma;
4. **descrizione di ogni skill**, oltre ai valori strutturati;
5. uso tattico e limiti/stato d'implementazione di ogni skill;
6. reaction/Fast Reaction e relativo stato;
7. equipaggiamento, varianti e talenti se definiti;
8. stato produzione e governance.

## Regole editoriali e di governance

- **v0.1:** i numeri e le semantiche competitive restano di proprietà dei cataloghi Markdown versionati in
  `docs/balance/` e dell'implementazione corrente. Il workbook v0.4 li rispecchia per la Wiki.
- **v0.2:** i dati sono `DATA_SPEC` / `DESIGN_SPEC`; non diventano runtime canonico finché non sono reviewati,
  implementati, validati e testati.
- Le descrizioni `Descrizione_Wiki` / `Uso_Tattico_Wiki` sono **testo editoriale derivato dai dati esistenti**:
  spiegano la regola, ma non aggiungono numeri o nuovi effetti.
- I campi mancanti restano `—` / `TBD`. Non completare automaticamente un valore solo per rendere la pagina piena.
- `PARTIAL`, `DEFERRED_E14` e `REVIEW_REQUIRED` devono essere visibili: una Wiki leggibile non deve nascondere
  i limiti dell'implementazione.
- Gli altri personaggi Paragon restano nel candidate pool del workbook, senza release e senza pagina operativa.
- Gli ID v0.2 `TBD` non vanno assegnati automaticamente.

## Fonte dati

`docs/balance/RefactorTactics_Characters_Wiki_Data_v0.4.xlsx`

Campi narrativi principali:

- `05_Hero_Mechanics.Descrizione_Wiki`
- `06_Abilities.Descrizione_Wiki`
- `06_Abilities.Uso_Tattico_Wiki`

La Wiki è una **vista documentale**. Il runtime non deve leggere i Markdown come fonte competitiva.
