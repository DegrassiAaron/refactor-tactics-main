# Character Wiki — indice

| Release | Personaggio | Ruolo | Meccanica firma | Stato | Pagina |
| --- | --- | --- | --- | --- | --- |
| v0.1 | Flux | Controller / Striker | Conduction | IMPLEMENTED / PARTIAL per alcune skill | [Flux](v0.1/flux.md) |
| v0.1 | Riva | Support / Controller | Water Shaping | IMPLEMENTED / PARTIAL; Flow Reaction E14 | [Riva](v0.1/riva.md) |
| v0.1 | Bastion | Guardian / Controller | Field Architecture | IMPLEMENTED / PARTIAL per strutture | [Bastion](v0.1/bastion.md) |
| v0.1 | Vektor | Striker / Controller | Predictive Interception | IMPLEMENTED_PARTIAL; Intercept Shot E14 | [Vektor](v0.1/vektor.md) |
| v0.2 | Steel | Guardian / Controller | Guard Meter | DATA_SPEC | [Steel](v0.2/steel.md) |
| v0.2 | Aurora | Controller / Striker | Frozen Domain | DATA_SPEC | [Aurora](v0.2/aurora.md) |
| v0.2 | Murdock | Marksman / Controller | Focus + Fire Sector | DATA_SPEC | [Murdock](v0.2/murdock.md) |
| v0.2 | Kwang | Bruiser / Controller | Electric Anchor | DATA_SPEC | [Kwang](v0.2/kwang.md) |

## Lettura rapida

La **v0.1** è il roster operativo corrente e viene descritta con il massimo dettaglio consentito dalle fonti
canoniche. Dove un effetto non è ancora completamente cablato, la pagina conserva `PARTIAL` o `DEFERRED_E14`.

La **v0.2** contiene i quattro personaggi successivi. Le pagine sono state rielaborate con lo stesso formato
narrativo della v0.1, ma i valori restano design data e non devono essere confusi con l'implementazione corrente.

> Gli altri candidati Paragon non fanno parte del roster ufficiale e non vengono pubblicati nella Wiki operativa.
